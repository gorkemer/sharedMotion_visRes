//alert("Your screen resolution is: " + screen.width + "x" + screen.height);

//alert("Your screen resolution is: " + window.screen.width * window.devicePixelRatio + "x" + window.screen.height * window.devicePixelRatio);
// function getResolution() {
//     alert("Your screen resolution is: " + window.screen.width * window.devicePixelRatio + "x" + window.screen.height * window.devicePixelRatio);
// }


// on_start(trial) {
// if (window.outerHeight == screen.height) {
//     if (window.outerHeight == window.innerHeight) {
//         var center_y = window.outerHeight*0.5;
//     }else{
//         var center_y = window.innerHeight*0.5;
//     }
// }else{
//     var center_y = window.innerHeight*0.5;
// }
// var center_x = window.innerWidth*0.475;
// trial.aperture_center_x = center_x;
// trial.aperture_center_y = center_y
//  },


/*        aperture_width: function() {
return window.innerWidth*0.1376;
},
aperture_height: function() {
return window.innerWidth*0.1376;
}, 
aperture_center_y:  function(){
return window.innerHeight/2;
},
aperture_center_x:  function(){
return window.innerWidth/2;
},*/



/*        canvas_width: function(){
return window.innerWidth
},
canvas_height: function(){
return window.innerHeight
},*/