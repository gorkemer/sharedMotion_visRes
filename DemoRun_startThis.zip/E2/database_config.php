<?php
  $servername = "localhost";
  $port = 3306;
  $username = "root";
  $password = "karabiber10";
  $dbname = "background-motion";
  $table = "backgroundMotion";
?>